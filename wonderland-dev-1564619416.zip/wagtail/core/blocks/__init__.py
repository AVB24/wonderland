# Import block types defined in submodules into the wagtail.core.blocks namespace
from .base import *  # NOQA
from .field_block import *  # NOQA
from .struct_block import *  # NOQA
from .list_block import *  # NOQA
from .stream_block import *  # NOQA
from .static_block import *  # NOQA
