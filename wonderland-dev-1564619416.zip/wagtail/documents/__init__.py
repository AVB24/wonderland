default_app_config = 'wagtail.documents.apps.WagtailDocsAppConfig'
