from ..v2.endpoints import DocumentsAPIEndpoint


class DocumentsAdminAPIEndpoint(DocumentsAPIEndpoint):
    pass
